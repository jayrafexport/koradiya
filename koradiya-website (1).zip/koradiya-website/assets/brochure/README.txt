Put your E-Catalogue / brochure PDF in this folder.

Default expected file name: catalogue.pdf
(matches the path already set in media.js)

If you name your file differently, or host it elsewhere on GitHub,
update the "brochure" line in media.js to match.
