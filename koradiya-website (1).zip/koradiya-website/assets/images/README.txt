Put your website images here using these file names
(or update the names in media.js to match your own files):

marble-slab-1.jpg, marble-slab-2.jpg          -> Marble Slab Collection photos
porcelain-tile-1.jpg ... porcelain-tile-4.jpg -> Porcelain Tiles photos
gallery-1.jpg ... gallery-6.jpg               -> facility / export photos
global-bg.jpg                                 -> background for the Global/export section

The hero slider, About photo, and two homepage product photos are
temporarily pulled from your existing (compromised) site so the page
isn't empty. Replace them with your own local files and update the
paths in media.js as soon as you can.
