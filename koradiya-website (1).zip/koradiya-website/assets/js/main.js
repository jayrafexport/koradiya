/* =========================================================
   KORADIYA GROUP IMPEX — SITE BEHAVIOR
   Runs after partials (header/footer) are mounted.
   ========================================================= */

document.addEventListener('partialsMounted', () => {

  /* ---------- scroll reveal ---------- */
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
    });
  }, { threshold: 0.14 });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));

  /* ---------- animated counters (data-count, data-suffix) ---------- */
  const counterIO = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el = e.target;
      const target = parseInt(el.dataset.count, 10) || 0;
      const suffix = el.dataset.suffix || '';
      const dur = 1400;
      const start = performance.now();
      function tick(now){
        const p = Math.min(1, (now - start) / dur);
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = Math.round(eased * target) + suffix;
        if (p < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      counterIO.unobserve(el);
    });
  }, { threshold: 0.5 });
  document.querySelectorAll('[data-count]').forEach(el => counterIO.observe(el));

  /* ---------- mission / vision / values accordion ---------- */
  document.querySelectorAll('.mvv-item').forEach(item => {
    const head = item.querySelector('.mvv-head');
    if (!head) return;
    head.addEventListener('click', () => {
      const isOpen = item.classList.contains('open');
      item.parentElement.querySelectorAll('.mvv-item').forEach(i => i.classList.remove('open'));
      if (!isOpen) item.classList.add('open');
    });
  });

  /* ---------- hero slider ---------- */
  const heroSlidesEl = document.getElementById('heroSlides');
  if (heroSlidesEl) {
    const M = window.SITE_MEDIA || {};
    const slides = M.heroSlides || [];
    slides.forEach((src, i) => {
      const d = document.createElement('div');
      d.className = 'hero-slide' + (i === 0 ? ' active' : '');
      d.style.backgroundImage = `url('${src}')`;
      heroSlidesEl.appendChild(d);
    });
    const dotsEl = document.getElementById('heroDots');
    const allSlideEls = () => heroSlidesEl.querySelectorAll('.hero-slide');
    if (slides.length > 1) {
      slides.forEach((_, i) => {
        const b = document.createElement('button');
        if (i === 0) b.classList.add('active');
        b.addEventListener('click', () => goTo(i));
        dotsEl.appendChild(b);
      });
      let cur = 0;
      function goTo(i){
        const els = allSlideEls();
        els[cur].classList.remove('active');
        dotsEl.children[cur].classList.remove('active');
        cur = i;
        els[cur].classList.add('active');
        dotsEl.children[cur].classList.add('active');
      }
      setInterval(() => goTo((cur + 1) % slides.length), 5500);
    }
  }

  /* ---------- testimonial slider ---------- */
  const testiWrap = document.getElementById('testiSlider');
  if (testiWrap) {
    const data = (window.SITE_CONTENT && window.SITE_CONTENT.testimonials) || [];
    const dotsWrap = document.getElementById('testiDots');
    data.forEach((t, i) => {
      const s = document.createElement('div');
      s.className = 'testi-slide' + (i === 0 ? ' active' : '');
      s.innerHTML = `<q>${t.quote}</q><div class="who">${t.who}</div>`;
      testiWrap.appendChild(s);
      const b = document.createElement('button');
      if (i === 0) b.classList.add('active');
      b.addEventListener('click', () => go(i));
      dotsWrap.appendChild(b);
    });
    let cur = 0;
    function go(i){
      testiWrap.children[cur].classList.remove('active');
      dotsWrap.children[cur].classList.remove('active');
      cur = i;
      testiWrap.children[cur].classList.add('active');
      dotsWrap.children[cur].classList.add('active');
    }
    if (data.length > 1) setInterval(() => go((cur + 1) % data.length), 6000);
  }

  /* ---------- process flow chart: draw line + reveal nodes on scroll ---------- */
  const flow = document.querySelector('.flow');
  if (flow) {
    const fill = flow.querySelector('.flow-line-fill');
    const steps = [...flow.querySelectorAll('.flow-step')];
    const flowIO = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (!e.isIntersecting) return;
        if (fill) fill.style.width = '100%';
        steps.forEach((s, i) => setTimeout(() => s.classList.add('in'), i * 180));
        flowIO.unobserve(flow);
      });
    }, { threshold: 0.3 });
    flowIO.observe(flow);
  }

  /* ---------- bar chart: animate bar heights from data-h (0-100) ---------- */
  const barChart = document.querySelector('.bar-chart');
  if (barChart) {
    const barIO = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (!e.isIntersecting) return;
        e.target.querySelectorAll('.bar').forEach(bar => {
          bar.style.height = (bar.dataset.h || 0) + '%';
        });
        barIO.unobserve(e.target);
      });
    }, { threshold: 0.3 });
    barIO.observe(barChart);
  }

  /* ---------- donut chart: animate conic-gradient from data-pct ---------- */
  const donut = document.querySelector('.donut');
  if (donut) {
    const pct = parseInt(donut.dataset.pct, 10) || 0;
    const donutIO = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (!e.isIntersecting) return;
        const deg = Math.round(pct * 3.6);
        donut.style.background = `conic-gradient(var(--teal) 0deg ${deg}deg, var(--line) ${deg}deg 360deg)`;
        donutIO.unobserve(donut);
      });
    }, { threshold: 0.4 });
    donutIO.observe(donut);
  }

  /* ---------- contact form -> mailto fallback ---------- */
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', function(e){
      e.preventDefault();
      const inputs = this.querySelectorAll('input, textarea');
      const [name, phone, email, message] = inputs;
      const body = `Name: ${name.value}%0APhone: ${phone.value}%0AEmail: ${email.value}%0A%0A${message.value}`;
      window.location.href = `mailto:info@koradiyagroupimpex.com?subject=Website Enquiry&body=${body}`;
    });
  }

  /* ---------- generic card-grid builder from content data ---------- */
  window.buildCards = function(containerId, items, render){
    const grid = document.getElementById(containerId);
    if (!grid) return;
    items.forEach(item => {
      const el = document.createElement('div');
      el.innerHTML = render(item);
      grid.appendChild(el.firstElementChild);
    });
  };

});
