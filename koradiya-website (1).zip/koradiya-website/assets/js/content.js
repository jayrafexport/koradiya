/* =========================================================
   KORADIYA GROUP IMPEX — CONTENT DATA
   Edit numbers, product sizes, countries, and process steps
   here. This is separate from media.js (images) so you can
   update wording without touching image paths.
   ========================================================= */

window.SITE_CONTENT = {

  heroStats: [
    { num: 800, suffix: '+', label: 'Unique Designs' },
    { num: 17,  suffix: '+', label: 'Countries Served' },
    { num: 7,   suffix: '',  label: 'Sizes Available' },
    { num: 24,  suffix: '/7', label: 'Customer Support' },
  ],

  process: [
    { step:'01', title:'Raw Material', text:'Clay, feldspar and quartz are sourced and tested for quality and consistency.' },
    { step:'02', title:'Pressing', text:'Material is pressed under high tonnage into precise tile bodies.' },
    { step:'03', title:'Glazing & Print', text:'Digital printing and glazing apply the design, pattern and finish.' },
    { step:'04', title:'Firing', text:'Tiles are fired at high kiln temperatures for strength and durability.' },
    { step:'05', title:'Quality Check', text:'Every batch is inspected for size, shade and surface consistency.' },
    { step:'06', title:'Pack & Export', text:'Tiles are palletised and export-packed for global shipment.' },
  ],

  marbleSlabSizes: ['1200 X 2780 MM', '600 X 1800 MM'],
  porcelainSizes: ['600 X 1200 MM', '300 X 600 MM', '600 X 600 MM', '800 X 800 MM', '1200 X 1200 MM', '1000 X 1000 MM'],

  productCategories: [
    {
      name:'Marble Slab Collection',
      desc:'Large-format vitrified slabs with marble-effect digital printing, for walls and premium flooring.',
      link:'products.html#marble-slab',
      img:'homeProductPhotos.0'
    },
    {
      name:'Porcelain Tiles',
      desc:'High-gloss and matte porcelain tiles in a wide range of sizes, patterns and finishes.',
      link:'products.html#porcelain',
      img:'homeProductPhotos.1'
    }
  ],

  whyChoose: [
    { ico:'&#9679;', title:'800+ Unique Designs', text:'A constantly growing catalogue of patterns, colours and finishes to match any project.' },
    { ico:'&#9670;', title:'Strict Quality Control', text:'Every batch is checked for shade consistency, surface finish and dimensional accuracy.' },
    { ico:'&#9733;', title:'Global Export Experience', text:'Shipping to 17+ countries with export documentation and packing handled end-to-end.' },
    { ico:'&#9711;', title:'24/7 Support', text:'A responsive team for export and domestic enquiries, from quote to delivery.' },
  ],

  countries: [
    { name:'United Arab Emirates', tag:'UAE' },
    { name:'South Africa', tag:'ZA' },
    { name:'United States', tag:'US' },
    { name:'Nepal', tag:'NP' },
    { name:'United Kingdom', tag:'UK' },
    { name:'Saudi Arabia', tag:'SA' },
  ],

  testimonials: [
    { quote:'Consistent shade matching across every pallet — exactly what our projects need for large-format installs.', who:'Import Partner — UAE' },
    { quote:'Packing and export documentation were handled smoothly from quote to container loading.', who:'Distributor — South Africa' },
    { quote:'Wide size range meant we could source everything from one supplier instead of three.', who:'Trading Partner — Nepal' },
  ],

  packingSteps: [
    { title:'Edge Protection', text:'Each tile is edge-protected before boxing to prevent chipping in transit.' },
    { title:'Carton Packing', text:'Tiles are boxed by size and shade batch, sealed and labelled for traceability.' },
    { title:'Pallet Stacking', text:'Cartons are stacked and strapped on export pallets to standard container dimensions.' },
    { title:'Shrink Wrapping', text:'Full pallets are shrink-wrapped for moisture and dust protection during shipping.' },
    { title:'Container Loading', text:'Pallets are loaded and braced for ocean or road freight, per destination requirements.' },
  ],

  infrastructure: [
    { title:'Pressing Units', text:'High-tonnage hydraulic presses forming consistent tile bodies at scale.' },
    { title:'Digital Printing Lines', text:'Rotary and inkjet printing lines applying high-resolution surface designs.' },
    { title:'Kiln Firing', text:'Temperature-controlled kilns for strength, durability and finish consistency.' },
    { title:'Quality Testing Lab', text:'In-house testing for size, water absorption, and surface quality before dispatch.' },
    { title:'Sorting & Packing', text:'Automated sorting by shade and size ahead of export-grade packing.' },
    { title:'Warehousing', text:'On-site storage capacity to support bulk export orders and quick dispatch.' },
  ],
};
