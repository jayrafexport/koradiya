/* =========================================================
   Shared header + footer, injected into every page.
   This is the ONE place nav links / footer content live —
   edit here once, it updates across all 8 pages.
   ========================================================= */

const HEADER_HTML = `
<div class="topbar">
  <div class="wrap">
    <div class="topbar-links">
      <a href="mailto:export@koradiyagroupimpex.com">export@koradiyagroupimpex.com</a>
      <a href="tel:+917777971693">+91 77779 71693</a>
      <span>Halvad, Morbi, Gujarat, India</span>
    </div>
    <div class="topbar-links">
      <a href="https://wa.me/917777971693" target="_blank" rel="noopener">WhatsApp</a>
      <a href="global.html">Exporting to 17+ Countries</a>
    </div>
  </div>
</div>
<header class="site-header" id="siteHeader">
  <div class="nav-inner wrap">
    <a href="index.html" class="brand">
      <img src="assets/logo/logo.png" alt="Koradiya Group Impex">
      <div class="brand-text">
        <span class="name">Koradiya Group Impex</span>
        <span class="tag">Tiles &amp; Marble Exporters</span>
      </div>
    </a>
    <button class="menu-toggle" id="menuToggle" aria-label="Toggle menu">&#9776;</button>
    <nav class="nav" id="mainNav">
      <div class="nav-item" data-page="index"><a href="index.html">Home</a></div>
      <div class="nav-item" data-page="company-profile,infrastructure">
        <span>Corporate <span class="caret">&#9660;</span></span>
        <div class="dropdown">
          <a href="company-profile.html">Company Profile</a>
          <a href="infrastructure.html">Infrastructure</a>
        </div>
      </div>
      <div class="nav-item" data-page="products"><a href="products.html">Products</a></div>
      <div class="nav-item" data-page="catalogue"><a href="catalogue.html">E-Catalogue</a></div>
      <div class="nav-item" data-page="packing-details">
        <span>Information <span class="caret">&#9660;</span></span>
        <div class="dropdown">
          <a href="packing-details.html">Packing Details</a>
        </div>
      </div>
      <div class="nav-item" data-page="global"><a href="global.html">Global</a></div>
      <div class="nav-item" data-page="contact"><a href="contact.html">Contact</a></div>
      <div class="nav-item" style="padding-left:8px;">
        <a href="contact.html" class="btn btn-clay btn-sm">Get a Quote</a>
      </div>
    </nav>
  </div>
</header>
`;

const FOOTER_HTML = `
<footer>
  <div class="wrap">
    <div class="footer-grid">
      <div class="footer-brand">
        <img src="assets/logo/logo.png" alt="Koradiya Group Impex">
        <p>Manufacturer and exporter of Porcelain Tiles, Digital Vitrified Tiles and Marble Slabs from Halvad, Morbi, Gujarat, India — serving 17+ countries.</p>
        <div class="socials">
          <a href="https://www.facebook.com/share/ZqgNNbSKjGXKV4Nv/?mibextid=qi2Omg" target="_blank" rel="noopener" aria-label="Facebook">f</a>
          <a href="https://www.instagram.com/koradiyaimpex" target="_blank" rel="noopener" aria-label="Instagram">ig</a>
          <a href="https://linkedin.com/in/koradiya-group-impex-223611284" target="_blank" rel="noopener" aria-label="LinkedIn">in</a>
          <a href="https://wa.me/917777971693" target="_blank" rel="noopener" aria-label="WhatsApp">wa</a>
        </div>
      </div>
      <div class="footer-col">
        <h5>Company</h5>
        <ul>
          <li><a href="company-profile.html">Company Profile</a></li>
          <li><a href="infrastructure.html">Infrastructure</a></li>
          <li><a href="products.html">Products</a></li>
          <li><a href="global.html">Global Reach</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h5>Resources</h5>
        <ul>
          <li><a href="catalogue.html">E-Catalogue</a></li>
          <li><a href="packing-details.html">Packing Details</a></li>
          <li><a href="contact.html">Contact Us</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h5>Get In Touch</h5>
        <ul>
          <li><p>Export: export@koradiyagroupimpex.com</p></li>
          <li><p>Domestic: info@koradiyagroupimpex.com</p></li>
          <li><p>+91 77779 71693</p></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <span id="year"></span> Koradiya Group Impex. All rights reserved.</span>
      <span>Manufacturer &amp; Exporter from Morbi, Gujarat, India</span>
    </div>
  </div>
</footer>
`;

function mountPartials(){
  document.getElementById('site-header').innerHTML = HEADER_HTML;
  document.getElementById('site-footer').innerHTML = FOOTER_HTML;

  const page = document.body.dataset.page || '';
  document.querySelectorAll('.nav-item[data-page]').forEach(item => {
    const keys = item.dataset.page.split(',');
    if (keys.includes(page)) item.classList.add('active');
  });

  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const menuToggle = document.getElementById('menuToggle');
  const mainNav = document.getElementById('mainNav');
  menuToggle.addEventListener('click', () => mainNav.classList.toggle('open'));
  mainNav.querySelectorAll('.nav-item').forEach(item => {
    const span = item.querySelector(':scope > span');
    if (span) span.addEventListener('click', () => { if (window.innerWidth <= 980) item.classList.toggle('mobile-open'); });
    item.querySelectorAll('a').forEach(a => a.addEventListener('click', () => { if (window.innerWidth <= 980) mainNav.classList.remove('open'); }));
  });

  const header = document.getElementById('siteHeader');
  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 10);
  });

  document.dispatchEvent(new Event('partialsMounted'));
}
document.addEventListener('DOMContentLoaded', mountPartials);
